package com.midnight.springkafkaerror;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaErrorApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringKafkaErrorApplication.class, args);
    }

}
